"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Client = void 0;
var Client = /** @class */ (function () {
    function Client(fullName, dateOfBirth, isActive, addresses, contacts) {
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
        this.isActive = isActive;
        this.addresses = addresses;
        this.contacts = contacts;
    }
    return Client;
}());
exports.Client = Client;
//# sourceMappingURL=client.js.map