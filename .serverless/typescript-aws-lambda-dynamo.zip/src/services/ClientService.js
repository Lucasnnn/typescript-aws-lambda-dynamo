"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientService = void 0;
var client_1 = require("../models/client");
var DBManager_1 = require("../utils/DBManager");
var ClientService = /** @class */ (function () {
    function ClientService() {
        this.DB = new DBManager_1.DBManager(process.env.DYNAMODB_CLIENT_TABLE, new client_1.Client());
    }
    ClientService.prototype.findAll = function () {
        return this.DB.getAll();
    };
    ClientService.prototype.create = function (body) {
        return this.DB.addItem(body);
    };
    return ClientService;
}());
exports.ClientService = ClientService;
//# sourceMappingURL=ClientService.js.map