"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientService = void 0;
var DBManager_1 = require("../utils/DBManager");
var ClientService = /** @class */ (function () {
    function ClientService() {
        this.DB = new DBManager_1.DBManager(process.env.DYNAMODB_CLIENT_TABLE);
    }
    ClientService.prototype.findAll = function () {
        return this.DB.getAll();
    };
    ClientService.prototype.findById = function (id) {
        return this.DB.getById(id);
    };
    ClientService.prototype.create = function (body) {
        return this.DB.addItem(body);
    };
    ClientService.prototype.update = function (id, body) {
        return this.DB.update(id, body);
    };
    ClientService.prototype.delete = function (id) {
        return this.DB.deleteItem(id);
    };
    return ClientService;
}());
exports.ClientService = ClientService;
//# sourceMappingURL=ClientService.js.map